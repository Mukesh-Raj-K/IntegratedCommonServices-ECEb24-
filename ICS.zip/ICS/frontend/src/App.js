import './App.css';
import { Navbar } from './components/Navbar/Navbar';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import { Home } from './pages/Home';
import { TransportPage } from './pages/Transport';
import { GovernmentServices } from './pages/GovernmentServices';
import { Health } from './pages/Health';
import { Education } from './pages/Education';
import { LoginSignup } from './pages/LoginSignup';

function App() {
  return (
    <div>
      <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/transport' element={<TransportPage/>}/>
        <Route path='/gov' element={<GovernmentServices/>}/>
        <Route path='/health' element={<Health/>}/>
        <Route path='/education' element={<Education/>}/>
        <Route path='/login' element={<LoginSignup/>}/>
      </Routes>
      </BrowserRouter>

      
    </div>
  );
}

export default App;
