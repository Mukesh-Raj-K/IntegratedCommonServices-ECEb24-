import React from 'react';
import './GovernmentServices.css';

const ServiceLink = ({ title, url }) => {
  return (
    <div className="service-link">
      <a href={url} target="_blank" rel="noopener noreferrer">
        {title}
      </a>
    </div>
  );
};

const GovernmentServices = () => {
  return (
    <div className="government-services-page">
      <h1>Government Services</h1>
      <div className="links-container">
        <ServiceLink title="Income Tax" url="https://www.incometax.gov.in/" />
        <ServiceLink title="Passport" url="https://passportindia.gov.in/" />
        <ServiceLink title="Aadhaar" url="https://uidai.gov.in/" />
        <ServiceLink title="PAN Card" url="https://www.onlineservices.nsdl.com/paam/endUserRegisterContact.html" />
      </div>
    </div>
  );
};

export { GovernmentServices };