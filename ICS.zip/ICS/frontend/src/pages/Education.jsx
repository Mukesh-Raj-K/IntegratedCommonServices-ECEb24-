import React from 'react';

const ServiceLink = ({ title, url }) => {
  return (
    <div className="service-link">
      <a href={url} target="_blank" rel="noopener noreferrer">
        {title}
      </a>
    </div>
  );
};

const Education = () => {
  return (
    <div className="education-services-page">
      <h1>Education</h1>
      <div className="links-container">
        <ServiceLink title="NCERT" url="https://ncert.nic.in/" />
        <ServiceLink title="CBSE" url="https://cbseacademic.nic.in/" />
        <ServiceLink title="NIOS" url="https://nios.ac.in/" />
        <ServiceLink title="AICTE" url="https://www.aicte-india.org/" />
      </div>
    </div>
  );
};

export { Education };