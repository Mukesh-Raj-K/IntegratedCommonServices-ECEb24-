import React from 'react';

const ServiceLink = ({ title, url }) => {
  return (
    <div className="service-link">
      <a href={url} target="_blank" rel="noopener noreferrer">
        {title}
      </a>
    </div>
  );
};

const Health = () => {
  return (
    <div className="health-services-page">
      <h1>Health</h1>
      <div className="links-container">
        <ServiceLink title="COVID-19 Information" url="https://www.mohfw.gov.in/" />
        <ServiceLink title="Ayushman Bharat" url="https://www.pmjay.gov.in/" />
        <ServiceLink title="Pharmacy" url="https://www.apollopharmacy.in" />
        <ServiceLink title="E-Sanjeevani Telemedicine" url="https://esanjeevaniopd.in/" />
      </div>
    </div>
  );
};

export { Health };
