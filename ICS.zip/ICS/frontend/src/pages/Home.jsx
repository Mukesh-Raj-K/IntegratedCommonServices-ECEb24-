import React from 'react'
import { Splash } from '../components/Splashpage/Splash'

export const Home = () => {
  return (
    <div>
        <Splash/>
    </div>
  )
}
