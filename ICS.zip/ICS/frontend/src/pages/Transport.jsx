import React from 'react';
import './Transport.css';
const TransportationLink = ({ title, url }) => {
  return (
    <div className="transportation-link">
      <a href={url} target="_blank" rel="noopener noreferrer">
        {title}
      </a>
    </div>
  );
};

const TransportPage = () => {
  return (
    <div className="transport-page">
      <h1>Transportation</h1>
      <div className="links-container">
        <TransportationLink title="Metro Trains" url="https://imetro.in" />
        <TransportationLink title="Cabs and Autos" url="https://www.olacabs.com" />
        <TransportationLink title="Railways" url="https://www.irctc.co.in/nget/train-search" />
        <TransportationLink title="Flights" url="https://www.makemytrip.com/flights/" />
      </div>
    </div>
  );
};

export { TransportPage };

