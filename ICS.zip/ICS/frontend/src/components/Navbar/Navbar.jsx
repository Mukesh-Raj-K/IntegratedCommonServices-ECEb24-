import React, { useState } from 'react'
import './Navbar.css'
import logo from '../assets/ICS.png'
import { Link } from 'react-router-dom'
export const Navbar = () => {
  const [menu,setMenu] = useState("home")
  return (
    <div className='navbar'>
      <div className='nav-logo'>
        <img src={logo} alt=""/>
        <p>Integrated Common Services</p>
      </div>
      <ul className='nav-menu'>
        <li onClick={()=>{setMenu("home")}}><Link style={{textDecoration: 'none'}} to= '/'>Home</Link>{menu==="home"?<hr/>:<></>}</li>
        <li onClick={()=>{setMenu("transport")}}><Link style={{textDecoration: 'none'}} to= '/transport'>Transport</Link>{menu==="transport"?<hr/>:<></>}</li>
        <li onClick={()=>{setMenu("gov")}}><Link style={{textDecoration: 'none'}} to= '/gov'>GovernmentServices</Link>{menu==="gov"?<hr/>:<></>}</li>
        <li onClick={()=>{setMenu("health")}}><Link style={{textDecoration: 'none'}} to= '/health'>Health</Link>{menu==="health"?<hr/>:<></>}</li>
        <li onClick={()=>{setMenu("education")}}><Link style={{textDecoration: 'none'}} to= '/education'>Education</Link>{menu==="education"?<hr/>:<></>}</li>
      </ul>
      <div className="nav-login">
        {localStorage.getItem('auth-token')
        ?<button onClick={()=>{localStorage.removeItem('auth-token');window.location.replace('/')}}>Logout</button>
        :<Link style={{textDecoration: 'none'}} to='/login'><button>Login</button></Link>}
        
      </div>
    </div>
  )
}
