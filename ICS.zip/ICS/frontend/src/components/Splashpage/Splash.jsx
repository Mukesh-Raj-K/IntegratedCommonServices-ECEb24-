    import React from 'react'
    import './Splash.css'
    export const Splash = () => {
    return (
        <div className="homepage">
        <header className="homepage-header">
            <h1>Welcome to Integrated Common Services</h1>
            <p>Your one-stop solution for government, health, education and transport services.</p>
        </header>
        <section className="features">
            <div className="feature">
            <h2>Government Services</h2>
            <p>Access various government services with ease.</p>
            </div>
            <div className="feature">
            <h2>Health Services</h2>
            <p>Find health services tailored to your needs.</p>
            </div>
            <div className="feature">
            <h2>Transport Services</h2>
            <p>Navigate through transport services effortlessly.</p>
            </div>
            <div className="feature">
                <h2>Education</h2>
                <p>Find Educational Institutions tailored to your needs.</p>
            </div>

        </section>
        </div>
    );
    };

